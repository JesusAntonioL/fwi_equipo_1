#ifndef LEPTON_I2C
#define LEPTON_I2C

void lepton_perform_ffc();
void lepton_reboot();

#endif
